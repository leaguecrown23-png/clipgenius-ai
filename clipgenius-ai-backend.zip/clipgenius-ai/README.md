# ClipGenius AI — backend funcional

## Qué hace
- Recibe archivos de video (MP4, MOV, MKV, WEBM, AVI, M4V).
- Transcribe el audio con Faster-Whisper.
- Selecciona hasta cinco ventanas candidatas usando densidad de voz y expresiones destacadas.
- Recorta y convierte a MP4 con FFmpeg.
- Incrusta subtítulos automáticos.
- Permite previsualizar y descargar los MP4 desde la web.

## Importante sobre YouTube
La opción de enlace permite identificar el video, pero **no descarga el archivo desde YouTube**. Un video público no implica permiso de descarga o reutilización. Para procesar un video pegado desde YouTube, adjuntá el archivo obtenido por un medio autorizado y asegurate de contar con derechos/permisos. No se implementa extracción ni evasión de restricciones de YouTube.

## Ejecutar con Docker (recomendado)
Requisitos: Docker Desktop o Docker Engine + Docker Compose.

1. Descomprimí el ZIP.
2. Abrí una terminal en la carpeta `clipgenius-ai`.
3. Ejecutá:

   ```bash
   docker compose up --build
   ```

4. Abrí `http://localhost:8000` en el navegador.

La primera ejecución descarga el modelo Whisper `small` (varios cientos de MB); puede tardar. El procesamiento se hace en la máquina donde corre Docker. En una computadora modesta, los videos largos pueden tardar bastante.

## Ejecutar sin Docker
Requisitos: Python 3.11+, FFmpeg y FFprobe instalados y disponibles en PATH.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## Configuración opcional
Variables de entorno:
- `WHISPER_MODEL`: tiny, base, small, medium, large-v3 (default: small).
- `WHISPER_DEVICE`: cpu o cuda.
- `WHISPER_COMPUTE_TYPE`: int8 para CPU; float16 suele usarse con CUDA.

## Límites de esta primera versión
- Selección automática basada en heurísticas de transcripción, no en un modelo semántico multimodal avanzado. Revisá los clips antes de publicar.
- El encuadre vertical es un recorte centrado; todavía no sigue automáticamente al hablante.
- Sin cuentas de usuario, pagos, almacenamiento persistente administrado ni cola de trabajos.
- No publiques el servidor directamente en internet sin autenticación, límites de uso, protección contra abuso y almacenamiento adecuado.
