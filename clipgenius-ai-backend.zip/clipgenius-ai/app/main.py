import os, re, uuid, shutil, subprocess
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from faster_whisper import WhisperModel

BASE = Path(__file__).resolve().parent.parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
UPLOADS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)

app = FastAPI(title="ClipGenius AI", version="1.0.0")
app.mount("/outputs", StaticFiles(directory=str(OUTPUTS)), name="outputs")
_model = None

def get_model():
    global _model
    if _model is None:
        model_name = os.getenv("WHISPER_MODEL", "small")
        device = os.getenv("WHISPER_DEVICE", "cpu")
        compute = os.getenv("WHISPER_COMPUTE_TYPE", "int8" if device == "cpu" else "float16")
        _model = WhisperModel(model_name, device=device, compute_type=compute)
    return _model

def run(cmd):
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode != 0:
        raise RuntimeError(p.stderr[-3000:])
    return p.stdout

def srt_time(seconds):
    ms = int(max(0, seconds) * 1000)
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"

def clean_name(s):
    return re.sub(r"[^a-zA-Z0-9_-]", "", s)[:40] or uuid.uuid4().hex[:8]

def get_duration(path):
    out = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
               "-of", "default=noprint_wrappers=1:nokey=1", str(path)])
    return float(out.strip())

def rank_windows(segments, total, clip_len):
    # Score transcript windows using speech density and highlight-language cues.
    cues = ["increíble", "importante", "secreto", "nunca", "siempre", "error", "mejor",
            "peor", "por qué", "cómo", "descubrí", "descubrimiento", "atención", "ojo",
            "resultado", "sorprendente", "impactante", "gracias", "problema", "solución",
            "increible", "atencion", "imposible", "verdad", "mentira", "love", "wow"]
    windows = []
    step = max(10, clip_len // 2)
    start = 0.0
    while start < max(1, total - 3):
        end = min(total, start + clip_len)
        selected = [s for s in segments if s["end"] > start and s["start"] < end]
        text = " ".join(s["text"] for s in selected).lower()
        words = re.findall(r"\w+", text)
        if len(words) >= 8:
            cue_score = sum(text.count(c) for c in cues)
            density = min(len(words) / max(1, clip_len), 3)
            # Prefer windows with enough speech and a few semantic hook words.
            score = density + cue_score * 1.8
            windows.append({"start": start, "end": end, "score": score, "text": text})
        start += step
    windows.sort(key=lambda x: x["score"], reverse=True)
    chosen = []
    for w in windows:
        if all(w["end"] <= c["start"] or w["start"] >= c["end"] for c in chosen):
            chosen.append(w)
        if len(chosen) == 5:
            break
    return sorted(chosen, key=lambda x: x["start"])

def write_srt(segments, start, end, path):
    rows = []
    idx = 1
    for seg in segments:
        a, b = max(start, seg["start"]), min(end, seg["end"])
        txt = seg["text"].strip()
        if b > a and txt:
            rows.append(f"{idx}\n{srt_time(a-start)} --> {srt_time(b-start)}\n{txt}\n")
            idx += 1
    Path(path).write_text("\n".join(rows), encoding="utf-8")

@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE / "index.html").read_text(encoding="utf-8")

@app.get("/api/health")
def health():
    return {"ok": True, "service": "ClipGenius AI"}

@app.post("/api/process")
async def process_video(
    file: UploadFile = File(...),
    clip_duration: int = Form(60),
    aspect: str = Form("9:16"),
    language: str = Form("es")
):
    if clip_duration not in (30, 60, 90):
        raise HTTPException(400, "Elegí clips de 30, 60 o 90 segundos.")
    if aspect not in ("9:16", "1:1", "16:9"):
        raise HTTPException(400, "Formato no válido.")
    suffix = Path(file.filename or "video.mp4").suffix.lower()
    if suffix not in (".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"):
        raise HTTPException(400, "Formato no admitido. Subí MP4, MOV, MKV, WEBM o AVI.")
    job = uuid.uuid4().hex[:12]
    source = UPLOADS / f"{job}{suffix}"
    try:
        size = 0
        with source.open("wb") as f:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > 1024 * 1024 * 1024:
                    raise HTTPException(413, "El archivo supera el límite de 1 GB.")
                f.write(chunk)
        duration = get_duration(source)
        if duration < 8:
            raise HTTPException(400, "El video es demasiado corto.")
        model = get_model()
        lang = None if language == "auto" else language
        transcribed, info = model.transcribe(str(source), language=lang, vad_filter=True,
                                             beam_size=5, word_timestamps=False)
        segments = [{"start": float(s.start), "end": float(s.end), "text": s.text.strip()}
                    for s in transcribed if s.text.strip()]
        if not segments:
            raise HTTPException(422, "No se pudo detectar voz. Probá con un video que tenga diálogo.")
        windows = rank_windows(segments, duration, min(clip_duration, int(duration)))
        if not windows:
            raise HTTPException(422, "No se encontraron fragmentos con suficiente voz.")
        made = []
        for i, w in enumerate(windows, 1):
            clip_id = f"{job}_clip_{i}"
            srt = OUTPUTS / f"{clip_id}.srt"
            out = OUTPUTS / f"{clip_id}.mp4"
            write_srt(segments, w["start"], w["end"], srt)
            if aspect == "9:16":
                vf = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
            elif aspect == "1:1":
                vf = "scale=1080:1080:force_original_aspect_ratio=increase,crop=1080:1080"
            else:
                vf = "scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080"
            # Subtitle path is escaped for FFmpeg's filter parser.
            srt_arg = str(srt.resolve()).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")
            vf += f",subtitles='{srt_arg}':force_style='FontName=Arial,FontSize=18,PrimaryColour=&H00FFFFFF,OutlineColour=&H80000000,BorderStyle=1,Outline=2,Shadow=1,Alignment=2,MarginV=90'"
            run(["ffmpeg", "-y", "-ss", str(w["start"]), "-i", str(source), "-t",
                 str(w["end"] - w["start"]), "-vf", vf, "-c:v", "libx264",
                 "-preset", "veryfast", "-crf", "23", "-c:a", "aac", "-b:a", "128k",
                 "-movflags", "+faststart", str(out)])
            made.append({
                "name": f"Clip destacado {i}",
                "start": round(w["start"], 1),
                "end": round(w["end"], 1),
                "score": round(w["score"], 2),
                "text": w["text"][:220],
                "url": f"/outputs/{out.name}"
            })
        return {"ok": True, "job_id": job, "detected_language": info.language,
                "clips": made, "message": f"Se generaron {len(made)} clips."}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"No se pudo procesar el video: {str(e)}")
    finally:
        try:
            await file.close()
        except Exception:
            pass
        # Keep uploaded source for debugging only during processing; remove afterwards.
        if source.exists():
            source.unlink(missing_ok=True)
